<?php
class Ticket{
	private $db_connection = null;
	public $errors = array();
	public $messages = array();
	
	public function __construct(){
		
	}
}
?>