<!--sidebar start-->
            <aside>
                <div id="sidebar" class="nav-collapse ">
                    <!-- sidebar menu start-->
                    <ul class="sidebar-menu">
                        <li class="active" data-menu="dashboard">
                            <a class="" href="#!/dashboard">
                                <i class="icon_house_alt"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li data-menu="transactions">
                            <a class="" href="#!/transactions">
                                <i class="fa fa-btc"></i>
                                <span>Transactions</span>
                            </a>
                        </li>
                        <li data-menu="messageTickets">
                            <a class="" href="#!/messageTickets">
                                <i class="fa fa-envelope"></i>
                                <span>Tickets</span>
                            </a>
                        </li>
                        <li data-menu="affiliate">
                            <a class="" href="#!/affiliate">
                                <i class="fa fa-sitemap"></i>
                                <span>Affiliate</span>
                            </a>
                        </li>
                        <li data-menu="account">
                            <a class="" href="#!/account">
                                <i class="icon_profile"></i>
                                <span>Account</span>
                            </a>
                        </li>
                        <li data-menu="logout">
                            <a class="" href="#!/logout">
                                <i class="fa fa-power-off"></i>
                                <span>Logout</span>
                            </a>
                        </li>
                    </ul>
                    <!-- sidebar menu end-->
                </div>
            </aside>
            <!--sidebar end-->